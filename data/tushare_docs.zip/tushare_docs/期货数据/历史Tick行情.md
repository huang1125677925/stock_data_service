# 期货Tick行情数据

源链接: https://tushare.pro/document/2?doc_id=314

<!-- 以下为原始HTML内容，Markdown可直接渲染 -->

<div class="content col-md-9 col-sm-8 col-xs-12">
<div class="search-panel">
<div class="search-container">
<span class="fa fa-search search-icon"></span>
<input class="search-input" placeholder="Search" type="text"/>
</div>
</div>
<h2 id="期货tick行情数据">期货Tick行情数据</h2>
<hr/>
<p>获取全市场期货合约的Tick高频行情，当前不提供API方式获取，只提供csv网盘交付，近10年历史数据，一次性网盘拷贝（支持按交易所按日期定制），每天增量更新。tick行情属于单独的数据服务内容，不在积分权限范畴，有需求的用户请微信联系：waditu_a ，联系时请注明期货tick数据。</p>
<br/>
<br/>
<p><strong>数据字段内容说明</strong></p>
<table>
<thead>
<tr>
<th>字段</th>
<th>类型</th>
<th>中文含义</th>
<th>样例</th>
</tr>
</thead>
<tbody><tr>
<td>InstrumentID</td>
<td>string</td>
<td>合约ID</td>
<td>cu2310</td>
</tr>
<tr>
<td>BidPrice1</td>
<td>float</td>
<td>买一价</td>
<td>68190.000000</td>
</tr>
<tr>
<td>BidVolume1</td>
<td>int</td>
<td>买一量</td>
<td>4</td>
</tr>
<tr>
<td>AskPrice1</td>
<td>float</td>
<td>卖一价</td>
<td>68212.000000</td>
</tr>
<tr>
<td>AskVolume1</td>
<td>int</td>
<td>卖一量</td>
<td>2</td>
</tr>
<tr>
<td>LastPrice</td>
<td>float</td>
<td>最新价</td>
<td>68210.000000</td>
</tr>
<tr>
<td>Volume</td>
<td>int</td>
<td>成交量</td>
<td>3223</td>
</tr>
<tr>
<td>Turnover</td>
<td>float</td>
<td>成交金额</td>
<td>382577245.000000</td>
</tr>
<tr>
<td>OpenInterest</td>
<td>int</td>
<td>持仓量</td>
<td>203332.000000</td>
</tr>
<tr>
<td>UpperLimitPrice</td>
<td>float</td>
<td>涨停价</td>
<td>68210.000000</td>
</tr>
<tr>
<td>LowerLimitPrice</td>
<td>float</td>
<td>跌停价</td>
<td>62210.000000</td>
</tr>
<tr>
<td>OpenPrice</td>
<td>float</td>
<td>今开盘</td>
<td>68010.000000</td>
</tr>
<tr>
<td>PreSettlementPrice</td>
<td>float</td>
<td>昨结算价</td>
<td>68110.000000</td>
</tr>
<tr>
<td>PreClosePrice</td>
<td>float</td>
<td>昨收盘价</td>
<td>68113.000000</td>
</tr>
<tr>
<td>PreOpenInterest</td>
<td>int</td>
<td>昨持仓量</td>
<td>3232343.000000</td>
</tr>
<tr>
<td>TradingDay</td>
<td>string</td>
<td>交易日期</td>
<td>20230925</td>
</tr>
<tr>
<td>UpdateTime</td>
<td>string</td>
<td>更新时间</td>
<td>10:00:00.500</td>
</tr>
</tbody></table>
<br/>
<br/>
<p><strong>文件样例</strong></p>
<img src="https://tushare.pro/files/web/ft_tick.png"/>
</div>
